#!/system/bin/sh
# Transsion (TECNO CLA5 / silead) UDFPS fix for GSI ROMs.
# Modified: preserve user's current screen brightness.
#
# HBM is enabled separately; normal backlight is never forced to max.

PATH=/system/bin:/system/xbin:/sbin
export PATH

HALNAME=fingerprint@2.1-service-mediatek
HBM=/sys/devices/platform/soc/14013000.dsi/lcm_hbm_state
BL=/sys/class/leds/lcd-backlight/brightness
BLMAX=/sys/class/leds/lcd-backlight/max_brightness
FPS=/proc/fingerprint_status
LOG=/data/local/tmp/udfps_fix.log

KG=/data/user_de/0/com.android.systemui/files/keyguard
TOUCH=/data/local/tmp/.fod_touch
UEVT=/data/adb/modules/transsion_udfps/uevent_fp

fod_on() {
    echo 1 > "$FPS" 2>/dev/null && echo "$(date +%F_%T) fod mode on" >> "$LOG"
}

find_hal() {
    for d in /proc/[0-9]*; do
        e=$(readlink "$d/exe" 2>/dev/null)
        case "$e" in
            *"$HALNAME"*)
                echo "${d#/proc/}"
                return 0
                ;;
        esac
    done
    return 1
}

# Wait for Android boot
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 300 ]; do
    sleep 2
    i=$((i+1))
done
sleep 8

echo "--- start $(date +%F_%T) ---" > "$LOG"
echo 0 > "$TOUCH"
fod_on

# Fingerprint capture delay
setprop persist.log.tag.fp.delay.screenon 80
setprop persist.log.tag.fp.delay.screenoff 80
setprop persist.log.tag.fp.delay.screenblind 80

chmod 755 "$UEVT" 2>/dev/null

# Warm up input
input >/dev/null 2>&1

(
    getevent -lt /dev/input/event5 2>/dev/null | while read -r line; do
        case "$line" in
            *00c3*DOWN*)
                read -r up _ < /proc/uptime
                echo "${up%%.*}" > "$TOUCH"

                woke=0
                if [ "$(cat "$KG" 2>/dev/null)" != "0" ]; then
                    input keyevent 224 >/dev/null 2>&1 &
                    woke=1
                fi

                if [ -x "$UEVT" ]; then
                    if [ "$woke" = "1" ]; then
                        (
                            sleep 0.05
                            "$UEVT" >/dev/null 2>&1
                            r=$?
                            echo "$(date +%F_%T) uevent fired rc=$r" >> "$LOG"
                        ) &
                    else
                        (
                            "$UEVT" >/dev/null 2>&1
                            r=$?
                            echo "$(date +%F_%T) uevent fired rc=$r" >> "$LOG"
                        ) &
                    fi
                else
                    echo "$(date +%F_%T) uevent missing $UEVT" >> "$LOG"
                fi
                ;;
        esac
    done
) &

gate_pid=""
gate_addr=""
ui_on="-1"
prev_bl=""
tick=0
fps=0
kg=0
kg_known=0
last_err=""

while true; do
    tick=$((tick+1))

    # 1. Keep HAL TP-finger-detect gate enabled
    if [ $((tick % 10)) -eq 0 ]; then
        p=$(find_hal)

        if [ -n "$p" ] && [ "$p" != "$gate_pid" ]; then
            l=$(grep 'libsl_fp_impl.so' "/proc/$p/maps" 2>/dev/null | grep 'r-xp' | head -n 1)

            if [ -n "$l" ]; then
                s=${l%%-*}
                gate_addr=$(awk -v s="$s" '
                    function h2d(x, i, d) {
                        d=0
                        for(i=1;i<=length(x);i++)
                            d=d*16+index("0123456789abcdef",tolower(substr(x,i,1)))-1
                        return d
                    }
                    BEGIN { printf "%.0f", h2d(s)+423084 }
                ')
                gate_pid=$p
                echo "$(date +%F_%T) gate pid=$p addr=$gate_addr" >> "$LOG"
            else
                if [ "$last_err" != "maps-$p" ]; then
                    echo "$(date +%F_%T) hal pid=$p maps unreadable, retrying" >> "$LOG"
                    last_err="maps-$p"
                fi
            fi
        fi

        if [ -n "$gate_addr" ] && [ -n "$p" ] && [ "$p" = "$gate_pid" ]; then
            c=$(dd if="/proc/$p/mem" bs=1 skip="$gate_addr" count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')

            if [ "$c" != "01" ]; then
                printf '\1' | dd of="/proc/$p/mem" bs=1 seek="$gate_addr" conv=notrunc 2>/dev/null
                c2=$(dd if="/proc/$p/mem" bs=1 skip="$gate_addr" count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')
                echo "$(date +%F_%T) gate set pid=$p was=$c now=$c2" >> "$LOG"
            fi
        else
            gate_pid=""
            gate_addr=""
        fi
    fi

    # 2. Read keyguard state
    read -r kg < "$KG" 2>/dev/null

    case "$kg" in
        1) kg_known=1 ;;
        0) kg_known=1 ;;
        *) kg=0; kg_known=0 ;;
    esac

    read -r up _ < /proc/uptime
    now=${up%%.*}

    last=0
    read -r last < "$TOUCH" 2>/dev/null
    case "$last" in
        ''|*[!0-9]*) last=0 ;;
    esac

    age=$((now-last))

    if [ $((tick % 10)) -eq 0 ]; then
        if timeout 5 dumpsys fingerprint 2>/dev/null | grep -q 'Fps state: 1'; then
            fps=1
        else
            fps=0
        fi
    fi

    want=0

    if [ "$kg" = "1" ]; then
        want=1
    elif [ "$fps" = "1" ] && [ "$age" -le 60 ]; then
        want=1
    elif [ "$kg_known" = "0" ] && [ "$age" -le 4 ]; then
        bl=$(cat "$BL" 2>/dev/null)
        if [ "$bl" = "0" ]; then
            want=1
        fi
    fi

    # 3. HBM control WITHOUT forcing maximum brightness
    if [ "$want" != "$ui_on" ]; then
        ui_on=$want

        if [ "$want" = "1" ]; then
            bl=$(cat "$BL" 2>/dev/null)

            # Save current brightness, but do not change it.
            if [ "$bl" != "0" ] && [ -n "$bl" ]; then
                prev_bl=$bl
            else
                prev_bl=""
            fi

            echo 1 > "$HBM"
            setprop sys.hbm.force 1
            fod_on

            echo "$(date +%F_%T) fp ui on (prev_bl=$prev_bl bl=$bl age=$age fps=$fps kg=$kg)" >> "$LOG"

        else
            echo 0 > "$HBM"
            setprop sys.hbm.force 0

            bl=$(cat "$BL" 2>/dev/null)

            if [ -n "$prev_bl" ] && [ "$bl" != "0" ]; then
                echo "$prev_bl" > "$BL" 2>/dev/null
            fi

            echo "$(date +%F_%T) fp ui off (restore_bl=$prev_bl bl=$bl age=$age fps=$fps kg=$kg)" >> "$LOG"
        fi
    fi

    # Heartbeat
    if [ $((tick % 300)) -eq 0 ]; then
        echo "$(date +%F_%T) alive pid=$p gate=$c ui=$ui_on kg=$kg age=$age fps=$fps" >> "$LOG"
    fi

    sleep 0.2
done
