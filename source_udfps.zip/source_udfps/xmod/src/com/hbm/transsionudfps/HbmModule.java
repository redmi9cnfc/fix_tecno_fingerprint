package com.hbm.transsionudfps;

import android.content.Context;
import android.content.res.Resources;
import android.app.KeyguardManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class HbmModule implements IXposedHookLoadPackage {

    private static final String TAG = "TranshitHBM";

    private static final String PROP_ENABLED = "persist.sys.phh.transsion_udfps_hbm";
    private static final String PROP_FORCE = "sys.hbm.force";
    private static final String PROP_FORCE_STANDALONE =
            "persist.sys.phh.udfps.hbm_force_standalone";
    private static final String PROP_MODE = "persist.sys.phh.udfps.hbm_mode";
    private static final String PROP_BAND = "persist.sys.phh.udfps.hbm_band";
    private static final String PROP_X = "persist.sys.phh.udfps.hbm_x";
    private static final String PROP_Y = "persist.sys.phh.udfps.hbm_y";
    private static final String PROP_RADIUS = "persist.sys.phh.udfps.hbm_radius";
    private static final String PROP_ICON = "persist.sys.phh.udfps.hbm_icon";
    private static final String PROP_INNER = "persist.sys.phh.udfps.hbm_inner";

    private static final String TITLE = "TranshitHBMController";

    private static final String ICON_PKG = "org.evolution.udfps.icons";
    private static final String ICON_ARRAY = "udfps_icons";
    private static final String ICON_SETTING = "udfps_icon";

    private static final String KG_FILE = "keyguard";

    private static final String BL_DIR = "/sys/class/leds/lcd-backlight/";
    private static final String BL_BRIGHTNESS = BL_DIR + "brightness";
    private static final String BL_MAX = BL_DIR + "max_brightness";

    private static final int TYPE = 0x7e8;
    private static final int FLAGS = 0x1000028 | 0x100 | 0x200 | 0x10;
    private static final int FORMAT_OPAQUE = -1;
    private static final int FORMAT_TRANSLUCENT = -3;

    private static final long HIDE_DELAY_MS = 150;
    private static final long[] ADD_RETRY_MS = { 30, 80, 200 };

    private static final long AUTH_STALE_MS = 5000;
    private static final long FORCE_STALE_MS = 15000;
    /* Grace window applies only when the device is UNLOCKED: there
     * onStartFingerprintNow may be a SystemUI wake-time auto-start. On the
     * lock screen a touch is a real touch, so no grace filter there. */
    private static final long SCREEN_ON_GRACE_MS = 1500;

    private static final int COLOR_GLYPH_IDLE = 0xFFB8B8B8;   /* grey */
    private static final int COLOR_GLYPH_TOUCH = 0xFF00E676;  /* green */
    private static final int ALPHA_GLYPH_IDLE = 110;
    private static final int ALPHA_GLYPH_TOUCH = 200;

    private static Handler sHandler;
    private static final Object LOCK = new Object();

    private static volatile Context sCtx;
    private static View sView;
    private static FrameLayout sRoot;
    private static volatile int sIconIndex = -1;
    private static volatile boolean sIconMissing;
    private static WindowManager sWm;
    private static volatile boolean sAuthRequested;
    private static volatile long sAuthSetAt;
    private static volatile boolean sAppAuthRequested;
    private static volatile boolean sLocked;
    private static volatile boolean sKgKnown;
    private static volatile boolean sTouching;
    private static volatile boolean sTouchingVisualApplied;
    private static volatile boolean sVisualInitialised;
    private static volatile long sLastScreenOnAt;
    private static String sSavedBrightness;
    private static Runnable sPendingHide;
    private static int sAddRetry;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        if (lp.processName != null && lp.processName.indexOf(':') >= 0) return;
        try {
            handle(lp);
        } catch (Throwable t) {
            log("init failed: " + t);
        }
    }

    private static void handle(LoadPackageParam lp) {
        sCtx = appContext();
        hookApplicationCreated();
        hookUdfpsController(lp);
        hookFingerprintAuth(lp);
        startForceWatcher();
        startKeyguardWatcher();
        log("hooks installed on " + lp.processName + " ctx=" + (sCtx != null));
    }

    /* ------------------------------------------------------------------ */
    /* Part 1: window management                                           */
    /* ------------------------------------------------------------------ */

    private static Context appContext() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method m = at.getMethod("currentApplication");
            Object app = m.invoke(null);
            if (app instanceof Context) return (Context) app;
        } catch (Throwable ignored) {}
        try {
            Class<?> helper = Class.forName("de.robv.android.xposed.AndroidAppHelper");
            Method m = helper.getMethod("currentApplication");
            Object app = m.invoke(null);
            if (app instanceof Context) return (Context) app;
        } catch (Throwable ignored) {}
        return null;
    }

    private static void hookApplicationCreated() {
        try {
            XposedHelpers.findAndHookMethod(android.app.Application.class, "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof Context) {
                                sCtx = (Context) param.thisObject;
                                log("application context captured");
                            }
                        }
                    });
        } catch (Throwable t) {
            log("app hook skipped: " + t);
        }
    }

    private static boolean isScreenOn(Context ctx) {
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isInteractive();
        } catch (Throwable t) {
            return true;
        }
    }

    /**
     * Should the window exist right now?
     *
     * On the lock screen the window is always shown in idle state (glyph
     * only, no disc) — the glyph is the affordance telling the user where
     * the sensor is. The white disc only appears while touching.
     */
    private static boolean shouldShowNow() {
        Context ctx = sCtx;
        if (ctx == null) return false;
        if (!isScreenOn(ctx)) return false;

        /* Lock screen: keep the glyph on screen for as long as it is up. */
        if (sKgKnown && sLocked) return true;

        boolean appAuth = sAppAuthRequested;
        boolean lockAuth = sAuthRequested && (!sKgKnown || sLocked);
        if (lockAuth && (System.currentTimeMillis() - sAuthSetAt) > AUTH_STALE_MS) {
            sAuthRequested = false;
            lockAuth = false;
        }
        boolean standalone = getBool(PROP_FORCE_STANDALONE, false);
        boolean force = getBool(PROP_FORCE, false);
        boolean forceActive = force && standalone;

        return appAuth || lockAuth || forceActive || sTouching;
    }

    /** Is the "touch" visual (white disc + green glyph) required? */
    private static boolean isTouchVisual() {
        if (sAppAuthRequested) return true;
        if (sTouching) return true;
        return false;
    }

    private static void startForceWatcher() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                boolean last = false;
                int tick = 0;
                boolean lastTouch = false;
                while (true) {
                    tick++;
                    boolean now;
                    try { now = shouldShowNow(); } catch (Throwable t) { now = false; }
                    if (now != last) {
                        last = now;
                        if (now) {
                            handler().post(new Runnable() {
                                @Override public void run() { requestShow("watch"); }
                            });
                        } else {
                            handler().post(new Runnable() {
                                @Override public void run() { requestHide("watch"); }
                            });
                        }
                    }
                    boolean touch = isTouchVisual();
                    if (now && touch != lastTouch) {
                        lastTouch = touch;
                        final boolean t2 = touch;
                        handler().post(new Runnable() {
                            @Override public void run() { repaintIcon(t2); }
                        });
                    }
                    if (now) {
                        final Context c = sCtx;
                        final FrameLayout root = sRoot;
                        if (c != null && root != null && (tick % 6) == 0) {
                            final int idx = readIconIndex(c);
                            boolean changed = idx >= 0 && idx != sIconIndex;
                            boolean retry = sIconMissing && iconPackInstalled(c);
                            if (changed || retry) {
                                handler().post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Context cc = sCtx;
                                        FrameLayout rr = sRoot;
                                        if (cc != null && rr != null) {
                                            repaintIcon(isTouchVisual());
                                            log("udfps icon redraw -> " + idx);
                                        }
                                    }
                                });
                            }
                        }
                    }
                    try { Thread.sleep(50); } catch (InterruptedException e) { return; }
                }
            }
        }, "TranshitHBM-watch");
        t.setDaemon(true);
        t.start();
    }

    private static void startKeyguardWatcher() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                String last = null;
                boolean lastScreenOn = false;
                while (true) {
                    try {
                        Context ctx = sCtx;
                        if (ctx != null) {
                            boolean screenOn = isScreenOn(ctx);
                            if (screenOn && !lastScreenOn) {
                                sLastScreenOnAt = System.currentTimeMillis();
                                log("screen on at " + sLastScreenOnAt);
                                sTouching = false;
                            }
                            lastScreenOn = screenOn;

                            KeyguardManager km = (KeyguardManager)
                                    ctx.getSystemService(Context.KEYGUARD_SERVICE);
                            boolean locked = km != null && km.isKeyguardLocked();
                            if (!sKgKnown || locked != sLocked) {
                                sLocked = locked;
                                sKgKnown = true;
                                if (!locked && !sAppAuthRequested) {
                                    handler().post(new Runnable() {
                                        @Override public void run() { requestHide("unlock"); }
                                    });
                                }
                            }
                            String v = locked ? "1" : "0";
                            if (!v.equals(last) && writeKeyguard(ctx, v)) {
                                last = v;
                                log("keyguard " + v);
                            }
                        }
                    } catch (Throwable ignored) {}
                    try { Thread.sleep(40); } catch (InterruptedException e) { return; }
                }
            }
        }, "TranshitHBM-kg");
        t.setDaemon(true);
        t.start();
    }

    private static boolean writeKeyguard(Context ctx, String v) {
        Context storage = ctx;
        try { storage = ctx.createDeviceProtectedStorageContext(); } catch (Throwable ignored) {}
        try {
            FileOutputStream fos = new FileOutputStream(new File(storage.getFilesDir(), KG_FILE));
            fos.write(v.getBytes("UTF-8"));
            fos.close();
            return true;
        } catch (Throwable t) {
            log("keyguard write failed: " + t);
            return false;
        }
    }

    private static void requestShow(String why) {
        synchronized (LOCK) {
            if (sPendingHide != null) {
                handler().removeCallbacks(sPendingHide);
                sPendingHide = null;
            }
            sAddRetry = 0;
            showWindowLocked(why);
        }
    }

    private static void requestHide(String why) {
        synchronized (LOCK) {
            if (sPendingHide != null) handler().removeCallbacks(sPendingHide);
            final String reason = why;
            sPendingHide = new Runnable() {
                @Override
                public void run() {
                    synchronized (LOCK) {
                        sPendingHide = null;
                        boolean stillNeeded;
                        try { stillNeeded = shouldShowNow(); }
                        catch (Throwable t) { stillNeeded = false; }
                        if (stillNeeded) {
                            log("hide(" + reason + ") cancelled: still needed");
                            return;
                        }
                        hideWindowLocked(reason);
                    }
                }
            };
            handler().postDelayed(sPendingHide, HIDE_DELAY_MS);
        }
    }

    private static void showWindowLocked(String why) {
        if (!getBool(PROP_ENABLED, true)) {
            log("disabled by " + PROP_ENABLED);
            return;
        }
        if (!shouldShowNow()) {
            log("showWindow(" + why + ") skipped: not needed now");
            return;
        }
        if (sView != null) {
            /* Already up: make sure the visual state is current. */
            if (!sVisualInitialised || sTouchingVisualApplied != isTouchVisual()) {
                repaintIcon(isTouchVisual());
            }
            return;
        }
        Context ctx = sCtx;
        if (ctx == null) { sCtx = appContext(); ctx = sCtx; }
        if (ctx == null) { log("showWindow: no context"); return; }
        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) { log("showWindow: no WindowManager"); return; }

        WindowManager.LayoutParams lp;
        String mode = getStr(PROP_MODE, "circle");
        final boolean circle = "circle".equals(mode);
        final int radius = getInt(PROP_RADIUS, 120);
        if (circle) {
            int cx = getInt(PROP_X, 540);
            int cy = getInt(PROP_Y, 2179);
            lp = new WindowManager.LayoutParams(
                    2 * radius, 2 * radius, cx - radius, cy - radius, TYPE, FLAGS, FORMAT_TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.LEFT;
        } else {
            int h = getInt(PROP_BAND, 520);
            lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, h, 0, 0,
                    TYPE, FLAGS, FORMAT_OPAQUE);
            lp.gravity = Gravity.BOTTOM | Gravity.LEFT;
        }
        lp.setTitle(TITLE);
        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_FULL;
        try { lp.setFitInsetsTypes(0); } catch (Throwable ignored) {}
        try {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } catch (Throwable ignored) {}

        View v;
        FrameLayout fl = null;
        final boolean touch = isTouchVisual();
        if (circle) {
            fl = new FrameLayout(ctx);
            applyIcon(ctx, fl, radius, touch);
            v = fl;
        } else {
            v = new View(ctx);
            v.setBackgroundColor(0xFFFFFFFF);
        }

        try {
            wm.addView(v, lp);
            sView = v;
            sWm = wm;
            sRoot = fl;
            sAddRetry = 0;
            sTouchingVisualApplied = touch;
            sVisualInitialised = true;
            if (circle && touch) boostBacklight();
            log("HBM window added (" + why + ", " + mode + ", touch=" + touch + ") "
                    + lp.width + "x" + lp.height + " at " + lp.x + "," + lp.y);
        } catch (Throwable t) {
            if (sAddRetry < ADD_RETRY_MS.length) {
                long delay = ADD_RETRY_MS[sAddRetry++];
                log("addView failed (" + t + "), retry " + sAddRetry + " in " + delay + "ms");
                handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        synchronized (LOCK) {
                            if (sView == null && sPendingHide == null) {
                                showWindowLocked("retry");
                            }
                        }
                    }
                }, delay);
            } else {
                log("addView failed permanently: " + t);
            }
        }
    }

    private static void hideWindowLocked(String why) {
        View v = sView;
        WindowManager wm = sWm;
        sView = null;
        sWm = null;
        sRoot = null;
        sIconIndex = -1;
        sIconMissing = false;
        sAddRetry = 0;
        sTouchingVisualApplied = false;
        sVisualInitialised = false;
        if (sPendingHide != null) {
            handler().removeCallbacks(sPendingHide);
            sPendingHide = null;
        }
        restoreBacklight();
        if (v == null || wm == null) return;
        try {
            wm.removeViewImmediate(v);
            log("HBM window removed (" + why + ")");
        } catch (Throwable t) {
            try {
                wm.removeView(v);
                log("HBM window removed (" + why + ", deferred)");
            } catch (Throwable t2) {
                log("removeView failed: " + t2);
            }
        }
    }

    /** Re-render the glyph in the requested visual state without recreating the window. */
    private static void repaintIcon(boolean touching) {
        Context ctx = sCtx;
        FrameLayout fl = sRoot;
        if (ctx == null || fl == null) {
            log("repaintIcon: no root (touch=" + touching + ")");
            return;
        }
        applyIcon(ctx, fl, getInt(PROP_RADIUS, 120), touching);
        sTouchingVisualApplied = touching;
        sVisualInitialised = true;
        if (touching) {
            boostBacklight();
        } else {
            restoreBacklight();
        }
        log("glyph repainted touch=" + touching);
    }

    /* ------------------------------------------------------------------ */
    /* Glyph loading (variant B: glyph is a ring, centre stays white)      */
    /* ------------------------------------------------------------------ */

    private static Drawable loadUdfpsIcon(Context ctx, boolean touching) {
        try {
            int idx = Settings.System.getInt(ctx.getContentResolver(), ICON_SETTING, 0);
            Resources res = ctx.getPackageManager().getResourcesForApplication(ICON_PKG);
            int arrayId = res.getIdentifier(ICON_ARRAY, "array", ICON_PKG);
            if (arrayId == 0) {
                log("udfps icon: no " + ICON_ARRAY);
                return null;
            }
            String[] names = res.getStringArray(arrayId);
            if (idx < 0 || idx >= names.length) {
                log("udfps icon: index " + idx + " out of range (" + names.length + ")");
                return null;
            }
            int drawableId = res.getIdentifier(names[idx], "drawable", ICON_PKG);
            if (drawableId == 0) {
                log("udfps icon: no drawable " + names[idx]);
                return null;
            }
            Drawable d = res.getDrawable(drawableId, null);
            if (d != null) {
                d = d.mutate();
                d.setColorFilter(touching ? COLOR_GLYPH_TOUCH : COLOR_GLYPH_IDLE,
                        PorterDuff.Mode.SRC_IN);
                d.setAlpha(touching ? ALPHA_GLYPH_TOUCH : ALPHA_GLYPH_IDLE);
            }
            log("udfps icon: " + idx + " -> " + names[idx] + " touch=" + touching);
            return d;
        } catch (Throwable t) {
            log("udfps icon: " + t);
            return null;
        }
    }

    private static int readIconIndex(Context ctx) {
        try {
            return Settings.System.getInt(ctx.getContentResolver(), ICON_SETTING, 0);
        } catch (Throwable t) { return -1; }
    }

    private static boolean iconPackInstalled(Context ctx) {
        try {
            ctx.getPackageManager().getPackageInfo(ICON_PKG, 0);
            return true;
        } catch (Throwable t) { return false; }
    }

    private static Bitmap fitToBitmap(Drawable icon, int size) {
        if (icon == null || size <= 0) return null;
        try {
            final int n = 256;
            Bitmap src = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(src);
            icon.setBounds(0, 0, n, n);
            icon.draw(c);

            int l = n, t = n, r = -1, b = -1;
            int[] row = new int[n];
            for (int y = 0; y < n; y++) {
                src.getPixels(row, 0, n, 0, y, n, 1);
                for (int x = 0; x < n; x++) {
                    if (((row[x] >>> 24) & 0xFF) > 8) {
                        if (x < l) l = x;
                        if (x > r) r = x;
                        if (y < t) t = y;
                        if (y > b) b = y;
                    }
                }
            }
            if (r < l || b < t) {
                src.recycle();
                return null;
            }
            int iw = r - l + 1;
            int ih = b - t + 1;
            Bitmap ink = Bitmap.createBitmap(src, l, t, iw, ih);
            Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas oc = new Canvas(out);
            float box = size * 0.98f;
            float scale = Math.min(box / iw, box / ih);
            int w = Math.max(1, Math.round(iw * scale));
            int h = Math.max(1, Math.round(ih * scale));
            int dx = (size - w) / 2;
            int dy = (size - h) / 2;
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            oc.drawBitmap(ink, null, new Rect(dx, dy, dx + w, dy + h), p);
            ink.recycle();
            src.recycle();
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Bitmap ringMask(Bitmap glyph, int size, float innerFrac) {
        if (glyph == null) return null;
        if (innerFrac < 0f) innerFrac = 0f;
        if (innerFrac > 0.95f) innerFrac = 0.95f;

        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawBitmap(glyph, 0, 0, null);

        Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
        clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        float r = size / 2f;
        c.drawCircle(r, r, r * innerFrac, clear);

        Paint keep = new Paint(Paint.ANTI_ALIAS_FLAG);
        keep.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawCircle(r, r, r, keep);

        glyph.recycle();
        return out;
    }

    /**
     * Idle: transparent background, glyph only (grey).
     * Touch: white disc under the glyph, glyph green.
     *
     * The glyph is ALWAYS drawn if the icon pack is available, in both states.
     * If the pack is missing we fall back to a thin grey ring so the user
     * still has an affordance; while touching the white disc under it keeps
     * the sensor lit.
     */
    private static void applyIcon(Context ctx, FrameLayout fl, int radius, boolean touching) {
        fl.removeAllViews();
        fl.setBackground(null);
        sIconMissing = false;

        final int size = radius * 2;

        /* Draw the white disc first (background), so the glyph is always on
         * top. Only in touch state. */
        if (touching) {
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(0xFFFFFFFF);
            fl.setBackground(gd);
        }

        boolean glyphDrawn = false;

        if (getBool(PROP_ICON, false)) {
            Drawable icon = loadUdfpsIcon(ctx, touching);
            if (icon != null) {
                Bitmap full = fitToBitmap(icon, size);
                if (full != null) {
                    float innerFrac = (float) getDoubleProp(PROP_INNER, 0.55);
                    Bitmap ring = ringMask(full, size, innerFrac);
                    if (ring != null) {
                        ImageView iv = new ImageView(ctx);
                        FrameLayout.LayoutParams ilp =
                                new FrameLayout.LayoutParams(size, size);
                        ilp.gravity = Gravity.CENTER;
                        iv.setLayoutParams(ilp);
                        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        iv.setImageBitmap(ring);
                        fl.addView(iv);
                        glyphDrawn = true;
                    }
                }
            } else if (!iconPackInstalled(ctx)) {
                log("udfps icon: no pack");
            } else {
                sIconMissing = true;
                log("udfps icon: glyph unavailable (will retry)");
            }
        }

        /* Fallback affordance: a thin ring so the UDFPS area is visible even
         * when no icon pack is installed or the glyph failed to load. */
        if (!glyphDrawn && !touching) {
            GradientDrawable ring = new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setColor(0x00000000); /* transparent fill */
            int stroke = Math.max(2, radius / 20);
            ring.setStroke(stroke, 0x66B8B8B8); /* grey stroke */
            FrameLayout.LayoutParams ilp =
                    new FrameLayout.LayoutParams(size - stroke * 2, size - stroke * 2);
            ilp.gravity = Gravity.CENTER;
            View ringView = new View(ctx);
            ringView.setBackground(ring);
            ringView.setLayoutParams(ilp);
            fl.addView(ringView);
            log("udfps icon: fallback ring");
        }

        sIconIndex = readIconIndex(ctx);
    }

    /* ------------------------------------------------------------------ */
    /* Backlight sysfs                                                     */
    /* ------------------------------------------------------------------ */

    private static void boostBacklight() {
        try {
            String cur = readFile(BL_BRIGHTNESS);
            String max = readFile(BL_MAX);
            if (cur == null || max == null) {
                log("backlight: cannot read nodes");
                return;
            }
            int maxVal = Integer.parseInt(max.trim());
            int curVal = Integer.parseInt(cur.trim());
            if (curVal >= maxVal) {
                log("backlight already at max " + maxVal);
                return;
            }
            if (sSavedBrightness == null) {
                if (curVal > 0) {
                    sSavedBrightness = cur.trim();
                } else {
                    log("backlight 0, boost without saving");
                    writeFile(BL_BRIGHTNESS, String.valueOf(maxVal));
                    return;
                }
            }
            writeFile(BL_BRIGHTNESS, String.valueOf(maxVal));
            log("backlight " + curVal + " -> " + maxVal);
        } catch (Throwable t) {
            log("backlight boost failed: " + t);
        }
    }

    private static void restoreBacklight() {
        String saved = sSavedBrightness;
        sSavedBrightness = null;
        if (saved == null) return;
        try {
            writeFile(BL_BRIGHTNESS, saved);
            log("backlight restored to " + saved);
        } catch (Throwable t) {
            log("backlight restore failed: " + t);
        }
    }

    private static String readFile(String path) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(new File(path));
            byte[] buf = new byte[64];
            int n = in.read(buf);
            return n > 0 ? new String(buf, 0, n) : null;
        } catch (Throwable t) {
            return null;
        } finally {
            if (in != null) { try { in.close(); } catch (Throwable ignored) {} }
        }
    }

    private static void writeFile(String path, String value) throws Exception {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File(path));
            out.write(value.getBytes("UTF-8"));
        } finally {
            if (out != null) { try { out.close(); } catch (Throwable ignored) {} }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Part 2: legacy UdfpsController hooks                                */
    /* ------------------------------------------------------------------ */

    private static void hookUdfpsController(LoadPackageParam lp) {
        try {
            Class<?> controller = XposedHelpers.findClass(
                    "com.android.systemui.biometrics.UdfpsController", lp.classLoader);

            XposedHelpers.findAndHookMethod(controller, "showUdfpsOverlay",
                    "com.android.systemui.biometrics.UdfpsControllerOverlay",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            log("showUdfpsOverlay()");
                            maybeMarkTouch("overlay");
                            handler().post(new Runnable() {
                                @Override public void run() { requestShow("udfps"); }
                            });
                        }
                    });

            XposedHelpers.findAndHookMethod(controller, "hideUdfpsOverlay",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            handler().post(new Runnable() {
                                @Override
                                public void run() {
                                    if (sAppAuthRequested) {
                                        log("hideUdfpsOverlay ignored: app auth active");
                                        return;
                                    }
                                    sTouching = false;
                                    /* On the lock screen keep the glyph up;
                                     * requestHide re-checks shouldShowNow(). */
                                    requestHide("udfps");
                                }
                            });
                        }
                    });
        } catch (Throwable t) {
            log("udfps hook skipped: " + t);
        }
    }

    /* ------------------------------------------------------------------ */
    /* Part 3: fingerprint auth                                            */
    /* ------------------------------------------------------------------ */

    /**
     * Mark "finger is on the sensor". The screen-on grace filter is applied
     * only when the device is UNLOCKED: there onStartFingerprintNow may be a
     * SystemUI wake-time auto-start. On the lock screen it is always a real
     * touch, so no filter.
     */
    private static void maybeMarkTouch(String source) {
        long now = System.currentTimeMillis();
        boolean unlocked = sKgKnown && !sLocked;
        long sinceScreenOn = now - sLastScreenOnAt;
        if (unlocked && sLastScreenOnAt != 0 && sinceScreenOn < SCREEN_ON_GRACE_MS) {
            log("markTouch(" + source + ") suppressed: " + sinceScreenOn
                    + "ms after screen-on (unlocked)");
            return;
        }
        if (!sTouching) {
            log("markTouch(" + source + ")");
            sTouching = true;
        }
        sAuthRequested = true;
        sAuthSetAt = now;
    }

    private static void hookFingerprintAuth(LoadPackageParam lp) {
        try {
            Class<?> auth = XposedHelpers.findClass(
                    "com.android.systemui.biometrics.AuthController", lp.classLoader);

            XposedHelpers.findAndHookMethod(auth, "onStartFingerprintNow", long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            log("onStartFingerprintNow()");
                            maybeMarkTouch("start");
                            handler().post(new Runnable() {
                                @Override public void run() { requestShow("auth"); }
                            });
                        }
                    });

            try {
                XposedHelpers.findAndHookMethod(auth, "onAcquired",
                        int.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                log("onAcquired(" + param.args[0] + ")");
                                sTouching = true;
                                sAuthRequested = true;
                                sAuthSetAt = System.currentTimeMillis();
                                handler().post(new Runnable() {
                                    @Override public void run() { requestShow("acquired"); }
                                });
                            }
                        });
            } catch (Throwable t) {
                log("onAcquired hook skipped (method not present): " + t);
            }

            try {
                XposedBridge.hookAllMethods(auth, "showAuthenticationDialog", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        log("showAuthenticationDialog() (app)");
                        sAppAuthRequested = true;
                        sTouching = true;
                        handler().post(new Runnable() {
                            @Override public void run() { requestShow("app"); }
                        });
                    }
                });
            } catch (Throwable t) {
                log("showAuthenticationDialog hook skipped: " + t);
            }

            try {
                XposedBridge.hookAllMethods(auth, "hideAuthenticationDialog", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        log("hideAuthenticationDialog() -> auth end");
                        sAuthRequested = false;
                        sAppAuthRequested = false;
                        sTouching = false;
                        handler().post(new Runnable() {
                            @Override public void run() { requestHide("app-end"); }
                        });
                    }
                });
            } catch (Throwable t) {
                log("hideAuthenticationDialog hook skipped: " + t);
            }

            try {
                XposedHelpers.findAndHookMethod(auth, "onBiometricError",
                        int.class, int.class, int.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                int errorCode = (Integer) param.args[0];
                                boolean appAuth = sAppAuthRequested;
                                boolean fatal =
                                        errorCode == 1 || errorCode == 3
                                        || errorCode == 5 || errorCode == 7
                                        || errorCode == 8 || errorCode == 9;
                                log("onBiometricError(" + errorCode + ") app=" + appAuth
                                        + " fatal=" + fatal);
                                if (!appAuth || fatal) {
                                    sAuthRequested = false;
                                }
                                sTouching = false;
                                handler().post(new Runnable() {
                                    @Override
                                    public void run() { repaintIcon(isTouchVisual()); }
                                });
                            }
                        });
            } catch (Throwable t) {
                log("onBiometricError hook skipped: " + t);
            }

            try {
                XposedHelpers.findAndHookMethod(auth, "onBiometricAuthenticated",
                        int.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                log("onBiometricAuthenticated() -> auth end");
                                sAuthRequested = false;
                                sAppAuthRequested = false;
                                sTouching = false;
                            }
                        });
            } catch (Throwable t) {
                log("onBiometricAuthenticated hook skipped: " + t);
            }

            try {
                XposedHelpers.findAndHookMethod(auth, "onDialogDismissed",
                        int.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                log("onDialogDismissed() -> auth end");
                                sAuthRequested = false;
                                sAppAuthRequested = false;
                                sTouching = false;
                                handler().post(new Runnable() {
                                    @Override public void run() { requestHide("dialog-end"); }
                                });
                            }
                        });
            } catch (Throwable t) {
                log("onDialogDismissed hook skipped: " + t);
            }
        } catch (Throwable t) {
            log("auth hook skipped: " + t);
        }
    }

    /* ------------------------------------------------------------------ */
    /* helpers                                                             */
    /* ------------------------------------------------------------------ */

    private static Handler handler() {
        if (sHandler == null) sHandler = new Handler(Looper.getMainLooper());
        return sHandler;
    }

    private static void log(String msg) {
        Log.i(TAG, msg);
        try { XposedBridge.log(TAG + ": " + msg); } catch (Throwable ignored) {}
    }

    private static String getStr(String key, String def) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method m = sp.getMethod("get", String.class, String.class);
            Object v = m.invoke(null, key, def);
            return v instanceof String ? (String) v : def;
        } catch (Throwable t) {
            return def;
        }
    }

    private static int getInt(String key, int def) {
        try { return Integer.parseInt(getStr(key, String.valueOf(def)).trim()); }
        catch (Throwable t) { return def; }
    }

    private static boolean getBool(String key, boolean def) {
        String v = getStr(key, def ? "true" : "false").trim();
        return "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
    }

    private static double getDoubleProp(String key, double def) {
        try { return Double.parseDouble(getStr(key, String.valueOf(def)).trim()); }
        catch (Throwable t) { return def; }
    }
}